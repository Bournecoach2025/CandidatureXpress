# CandidatureXpress

Automatisation 100% gratuite de candidatures sur les plus grands sites d'emploi.

## Fonctionnalités
- Scraping d'offres d'emploi sur LinkedIn, Indeed, Glassdoor, APEC, Google Jobs
- Filtres par mots-clés, ville, salaire
- Envoi automatique de candidatures avec CV + lettre de motivation
- Suivi des candidatures dans un fichier Excel
- Exécutable via Google Colab ou PythonAnywhere 24h/24

## Utilisation
Voir `colab_launcher.ipynb` ou les instructions dans le README complet.
